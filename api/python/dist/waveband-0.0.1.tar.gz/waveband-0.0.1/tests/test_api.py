from . import API

def test_api():
    api = API("waveband.thijmens.nl")
    assert api.get() != None
