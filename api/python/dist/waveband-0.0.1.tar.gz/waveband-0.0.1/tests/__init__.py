# SPDX-FileCopyrightText: 2025 Craig Giles
#
# SPDX-License-Identifier: MIT
from waveband import API, MalformedResponse
