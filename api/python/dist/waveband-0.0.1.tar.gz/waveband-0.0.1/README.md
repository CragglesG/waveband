# waveband

[![PyPI - Version](https://img.shields.io/pypi/v/waveband.svg)](https://pypi.org/project/waveband)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/waveband.svg)](https://pypi.org/project/waveband)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install waveband
```

## License

`waveband` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
