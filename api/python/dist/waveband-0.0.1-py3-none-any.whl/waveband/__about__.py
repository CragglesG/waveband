# SPDX-FileCopyrightText: 2025 Craig Giles
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
