import socket

class MalformedResponse(Exception):
    pass

class API:
    def __init__(self, url: str, port: int = 80, token: str = ""):
        self.url = url
        self.port = port
        self.token = token

    def get(self) -> bytes:
        token = self.token.encode()
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((self.url, self.port))

        receiving = True
        data = b""
        while receiving:
            data = s.recv(1024)
            if not data:
                receiving = False
        if not data.strip() == b"Hello":
            s.close()
            raise MalformedResponse("Invalid response")

        s.send(b"Hi\r\n")
        s.send(len(token).to_bytes(2, 'big') + token + b"\r\n")

        receiving = True
        data = b""
        while receiving:
            data = s.recv(1024)
            if not data:
                receiving = False

        s.close()
        return data
